var siteNameInput = document.getElementById('siteName');
var siteUrlInput = document.getElementById('siteUrl');
var bookmarks = JSON.parse(localStorage.getItem("bookmark") || "[]");

function display() {
    var content = "";
    for (var i = 0; i < bookmarks.length; i++) {
        content += `
        <div class="bg- text-center row mb-2">
            <div class="col-3"><p>${i + 1}</p></div>
            <div class="col-3"><p>${bookmarks[i].name}</p></div>
            <div class="col-3">
                <a target="_blank" href="${bookmarks[i].url}" class="btn btn-outline-success">Visit</a>
            </div>
            <div class="col-3">
                <button class="btn btn-danger" onclick="deleteBookmark(${i})">Delete</button>
            </div>
        </div>`;
    }
    document.getElementById('container').innerHTML = content;
}

function addBookmark() {
    var name = siteNameInput.value;
    var url = siteUrlInput.value;

    if (!name || !url) {
        alert("Please enter both Site Name and URL.");
        return;
    }

    if (!url.startsWith("http://") && !url.startsWith("https://")) {
        alert("Invalid URL. Please include http:// or https://");
        return;
    }

    // Check for duplicate URLs
    if (bookmarks.some(bookmark => bookmark.url === url)) {
        alert("This URL is already saved.");
        return;
    }

    // Add bookmark to the array and save to localStorage
    bookmarks.push({ name: name, url: url });
    localStorage.setItem("bookmark", JSON.stringify(bookmarks));
    
    // Clear inputs and update display
    siteNameInput.value = "";
    siteUrlInput.value = "";
    display();
}

function deleteBookmark(index) {
    bookmarks.splice(index, 1);
    localStorage.setItem("bookmark", JSON.stringify(bookmarks));
    display();
}

// Display bookmarks when the page loads
display();
